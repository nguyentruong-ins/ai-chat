package com.leon.gptclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GptCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(GptCloneApplication.class, args);
	}

}
